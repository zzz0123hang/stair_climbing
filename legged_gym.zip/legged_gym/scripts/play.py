import sys
from legged_gym import LEGGED_GYM_ROOT_DIR
import os
import isaacgym
from legged_gym.envs import *
from legged_gym.utils import  get_args, export_policy_as_jit, task_registry, Logger
from pynput import keyboard
import threading
import cv2
import numpy as np
import torch

# 全局变量存储速度命令
current_lin_vel_x = 0.0 # 前后
current_lin_vel_y = 0.0 # 左右
current_ang_vel_yaw = 0.0 # 转向
lock = threading.Lock()

def on_press(key):
    """键盘按下事件回调函数"""
    global current_lin_vel_x, current_lin_vel_y, current_ang_vel_yaw
    try:
        with lock:
            # W/S: 前后移动
            if key.char == 'w':
                current_lin_vel_x = 1
            elif key.char == 's':
                current_lin_vel_x = -1
            
            # A/D: 左右平移 (Side Step)
            elif key.char == 'a':
                current_lin_vel_y = 0.5
            elif key.char == 'd':
                current_lin_vel_y = -0.5
            
            # Q/E: 左右旋转 (Turning) - G1需要这个！
            elif key.char == 'q':
                current_ang_vel_yaw = 0.5
            elif key.char == 'e':
                current_ang_vel_yaw = -0.5
                
    except AttributeError:
        pass

def on_release(key):
    """键盘释放事件回调函数"""
    global current_lin_vel_x, current_lin_vel_y, current_ang_vel_yaw
    try:
        with lock:
            if key.char in ('w', 's'):
                current_lin_vel_x = 0.0
            elif key.char in ('a', 'd'):
                current_lin_vel_y = 0.0
            elif key.char in ('q', 'e'):
                current_ang_vel_yaw = 0.0
    except AttributeError:
        pass

def show_depth_map_cv2(env, env_idx=0):
    """
    [Warp 专用] 可视化 8x8 深度图
    """
    # 1. 安全检查：确认环境里是否输出了深度图
    if not hasattr(env, 'extras') or "depth_camera" not in env.extras:
        return

    try:
        # 2. 获取数据 (注意：从 extras 获取，而不是 cam_out)
        # 形状通常是 (num_envs, H, W) 或 (num_envs, 1, H, W)
        raw_tensor = env.extras["depth_camera"][env_idx]
        
        # 3. 转换为 Numpy 数组
        depth_map = raw_tensor.detach().cpu().numpy()
        
        # 如果维度是 (1, 8, 8) 则压缩成 (8, 8)
        if depth_map.ndim == 3:
            depth_map = depth_map.squeeze(0)
            
        # 4. 数据清洗 (处理 Warp 渲染天空时可能产生的 inf)
        # 将无限远(inf)替换为 0 或 最大距离
        depth_map = np.nan_to_num(depth_map, posinf=5.0, neginf=0.0)
        
        # 5. 归一化与着色
        # 强制归一化到 0~5米 范围，这样颜色对应的距离是固定的，不会闪烁
        MAX_RANGE = 5.0
        norm_data = np.clip(depth_map / MAX_RANGE, 0, 1) * 255
        depth_uint8 = norm_data.astype(np.uint8)
        
        # 使用伪彩色 (Inferno 或 Jet 配色对深度图更直观)
        colored = cv2.applyColorMap(depth_uint8, cv2.COLORMAP_INFERNO)
        
        # 6. 【关键】放大图像
        # 原始 8x8 像素太小看不清，放大到 400x400
        # INTER_NEAREST (最近邻插值) 能保留像素格子的边缘，让你看清神经网络到底看见了哪几个格子
        display_img = cv2.resize(colored, (400, 400), interpolation=cv2.INTER_NEAREST)
        
        # 7. 添加文字信息
        min_val = depth_map.min()
        max_val = depth_map.max()
        
        # 显示当前最小值和最大值
        cv2.putText(display_img, f"Range: {min_val:.1f}m - {max_val:.1f}m", (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
        
        # 显示图像
        cv2.imshow("Warp Depth (8x8 Input)", display_img)
        cv2.waitKey(1) # 刷新窗口
        
    except Exception as e:
        print(f"可视化出错: {e}")
        
    except Exception as e:
        # 避免刷屏报错，只报一次
        if not hasattr(show_depth_map_cv2, "has_errored"):
            print(f"深度图显示出错: {e}")
            show_depth_map_cv2.has_errored = True

def play(args):
    """主运行函数"""
    env_cfg, train_cfg = task_registry.get_cfgs(name=args.task)
    
    # --- 覆盖参数以适应 Play 模式 ---
    env_cfg.env.num_envs = min(env_cfg.env.num_envs, 9)  # 只开几个环境测试，不用开太多
    env_cfg.terrain.num_rows = 5
    env_cfg.terrain.num_cols = 5
    env_cfg.terrain.curriculum = False
    env_cfg.noise.add_noise = False
    env_cfg.domain_rand.randomize_friction = False
    env_cfg.domain_rand.push_robots = False
    
    # 【重要】确保相机开启，否则没数据
    env_cfg.sensor.stereo_cam.enable = True 
    env_cfg.env.test = True

    # 创建环境
    env, _ = task_registry.make_env(name=args.task, args=args, env_cfg=env_cfg)
    obs = env.get_observations()
    
    # 加载策略
    train_cfg.runner.resume = True
    ppo_runner, train_cfg = task_registry.make_alg_runner(env=env, name=args.task, args=args, train_cfg=train_cfg)
    policy = ppo_runner.get_inference_policy(device=env.device)
    
    # 导出 JIT (可选)
    if EXPORT_POLICY:
        path = os.path.join(LEGGED_GYM_ROOT_DIR, 'logs', train_cfg.runner.experiment_name, 'exported', 'policies')
        export_policy_as_jit(ppo_runner.alg.actor_critic, path)
        print('Exported policy as jit script to: ', path)
    
    # 初始化 OpenCV
    cv2.namedWindow("Warp Depth (Actor Input)", cv2.WINDOW_NORMAL)
    
    print("\n" + "="*30)
    print("🎮 G1 键盘控制:")
    print("  W / S : 前进 / 后退")
    print("  A / D : 左右平移")
    print("  Q / E : 左右转向 (新增)")
    print("  ESC   : 退出")
    print("="*30 + "\n")
    
    # 主循环
    try:
        while True:
            # 1. 策略推理
            with torch.no_grad():
                actions = policy(obs.detach())
            
            # 2. 应用键盘指令
            with lock:
                # 假设 commands 顺序: [lin_vel_x, lin_vel_y, ang_vel_yaw]
                env.commands[:, 0] = current_lin_vel_x
                env.commands[:, 1] = current_lin_vel_y
                env.commands[:, 2] = current_ang_vel_yaw
                env.commands[:, 3] = 0.0
            
            # 3. 环境步进
            obs, _, rews, dones, infos = env.step(actions.detach())

            # 4. 可视化
            show_depth_map_cv2(env, env_idx=0)
            
            # 5. 退出控制
            key = cv2.waitKey(1) & 0xFF
            if key == 27 or key == ord('q'): # ESC or Q to quit
                break
                
    except KeyboardInterrupt:
        pass
    
    cv2.destroyAllWindows()
    print("程序结束")

if __name__ == '__main__':
    EXPORT_POLICY = True
    
    # 启动键盘监听
    listener = keyboard.Listener(on_press=on_press, on_release=on_release)
    listener.start()
    
    args = get_args()
    play(args)